import os

CGROUP_BASE = "/sys/fs/cgroup"

def write_file(path, value):
    with open(path, "w") as f:
        f.write(str(value))

def apply_cgroup_limits(container_id):
    print("[+] Applying cgroup limits...")
    path = f"{CGROUP_BASE}/mycontainers/{container_id}"
    os.makedirs(path, exist_ok=True)

    # محدود کردن حافظه (50MB)
    write_file(f"{path}/memory.max", 50 * 1024 * 1024)

    # محدود کردن CPU (مثلاً 25%)
    os.makedirs(f"{CGROUP_BASE}/cpu/mycontainers/{container_id}", exist_ok=True)
    write_file(f"{CGROUP_BASE}/cpu/mycontainers/{container_id}/cpu.max", "25000 100000")

    # اضافه کردن PID جاری به cgroup
    write_file(f"{path}/cgroup.procs", os.getpid())

def freeze_container(container_id):
    path = f"{CGROUP_BASE}/{container_id}"
    os.makedirs(path, exist_ok=True)
    write_file(f"{path}/cgroup.freeze", 1)
    print(f"[+] Container {container_id} frozen (cgroup v2).")

def unfreeze_container(container_id):
    path = f"{CGROUP_BASE}/{container_id}"
    write_file(f"{path}/cgroup.freeze", 0)
    print(f"[+] Container {container_id} resumed (cgroup v2).")
